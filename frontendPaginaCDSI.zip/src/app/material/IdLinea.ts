export class IdLinea{
    cia:string;
    tipo:string;
    codigo:string;
}