import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trabajos-realizados',
  templateUrl: './trabajos-realizados.component.html',
  styleUrls: ['./trabajos-realizados.component.css']
})
export class TrabajosRealizadosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
