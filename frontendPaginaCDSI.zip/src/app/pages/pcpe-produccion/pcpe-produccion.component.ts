import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pcpe-produccion',
  templateUrl: './pcpe-produccion.component.html',
  styleUrls: ['./pcpe-produccion.component.css']
})
export class PcpeProduccionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
