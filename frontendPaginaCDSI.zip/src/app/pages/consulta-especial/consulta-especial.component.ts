import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-especial',
  templateUrl: './consulta-especial.component.html',
  styleUrls: ['./consulta-especial.component.css']
})
export class ConsultaEspecialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
