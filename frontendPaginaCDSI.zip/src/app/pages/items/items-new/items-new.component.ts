import { Component, OnInit } from "@angular/core";

@Component({
  selector: 'app-items-new',
  templateUrl: './items-new.component.html',
  styleUrls: []
})

export class NewItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
  

}
