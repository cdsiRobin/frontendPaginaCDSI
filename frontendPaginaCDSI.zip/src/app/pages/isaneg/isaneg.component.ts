import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-isaneg',
  templateUrl: './isaneg.component.html',
  styleUrls: ['./isaneg.component.css']
})
export class IsanegComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
