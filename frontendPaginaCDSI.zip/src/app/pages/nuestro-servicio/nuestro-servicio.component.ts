import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nuestro-servicio',
  templateUrl: './nuestro-servicio.component.html',
  styleUrls: ['./nuestro-servicio.component.css']
})
export class NuestroServicioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
