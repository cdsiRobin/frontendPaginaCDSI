import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ciope',
  templateUrl: './ciope.component.html',
  styleUrls: ['./ciope.component.css']
})
export class CiopeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
