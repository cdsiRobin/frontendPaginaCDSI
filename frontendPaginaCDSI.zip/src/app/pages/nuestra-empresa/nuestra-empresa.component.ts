import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nuestra-empresa',
  templateUrl: './nuestra-empresa.component.html',
  styleUrls: ['./nuestra-empresa.component.css']
})
export class NuestraEmpresaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
