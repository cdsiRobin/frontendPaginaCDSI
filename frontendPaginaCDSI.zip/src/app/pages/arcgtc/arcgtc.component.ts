import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arcgtc',
  templateUrl: './arcgtc.component.html'
})
export class ArcgtcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
