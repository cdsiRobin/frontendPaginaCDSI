import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pcpe-sileg',
  templateUrl: './pcpe-sileg.component.html',
  styleUrls: ['./pcpe-sileg.component.css']
})
export class PcpeSilegComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
