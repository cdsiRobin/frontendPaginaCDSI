import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alianzas',
  templateUrl: './alianzas.component.html',
  styleUrls: ['./alianzas.component.css']
})
export class AlianzasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
