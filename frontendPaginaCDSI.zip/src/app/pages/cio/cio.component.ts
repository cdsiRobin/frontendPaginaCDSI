import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cio',
  templateUrl: './cio.component.html',
  styleUrls: ['./cio.component.css']
})
export class CioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
