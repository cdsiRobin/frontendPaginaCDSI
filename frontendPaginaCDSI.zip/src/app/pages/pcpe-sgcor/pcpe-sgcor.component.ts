import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pcpe-sgcor',
  templateUrl: './pcpe-sgcor.component.html',
  styleUrls: ['./pcpe-sgcor.component.css']
})
export class PcpeSgcorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
