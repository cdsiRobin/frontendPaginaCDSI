import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nuestro-productos',
  templateUrl: './nuestro-productos.component.html',
  styleUrls: ['./nuestro-productos.component.css']
})
export class NuestroProductosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
