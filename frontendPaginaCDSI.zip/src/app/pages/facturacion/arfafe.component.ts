import { Component, OnInit } from "@angular/core";

@Component({
  selector: 'app-arfafe',
  templateUrl: './arfafe.component.html',
  styleUrls: []
})

export class ArfafeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
  

}
