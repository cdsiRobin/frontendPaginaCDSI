import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sgcor',
  templateUrl: './sgcor.component.html',
  styleUrls: ['./sgcor.component.css']
})
export class SgcorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
