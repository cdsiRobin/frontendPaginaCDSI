import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pcpe-sgdi',
  templateUrl: './pcpe-sgdi.component.html',
  styleUrls: ['./pcpe-sgdi.component.css']
})
export class PcpeSgdiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
