export class IdArcaaccaj{
  cia:string;
  centro: string;
  codCaja: string;
  cod_aper: string;
}
