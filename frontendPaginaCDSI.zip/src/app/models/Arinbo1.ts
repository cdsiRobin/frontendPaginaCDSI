import { IdArinbo1 } from './IdArinbo1';
export class Arinbo1{
  idArinb:IdArinbo1;
    descripcion:string;
}
