export class IdArfatp{
    cia:string;
    tipo:string;
}