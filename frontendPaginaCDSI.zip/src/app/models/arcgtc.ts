import { ArcgtcPK } from './arcgtc-pk';

export class Arcgtc {
  arcgtcPK: ArcgtcPK;
  tipoCambio: number;
}
