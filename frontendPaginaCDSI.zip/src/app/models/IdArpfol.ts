export class IdArpfol {
  noCia: string;
  noOrden: string;
  noArti: string;
}
