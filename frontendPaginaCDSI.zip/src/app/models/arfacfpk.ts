export class Arfacfpk {
    noCia:string;
    centro:string;
}