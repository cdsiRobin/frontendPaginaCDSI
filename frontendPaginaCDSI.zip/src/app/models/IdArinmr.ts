export class IdArinmr{
     cia:string;
     codigo:string;
}