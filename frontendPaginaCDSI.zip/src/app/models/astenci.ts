export class Astenci {
    public id: number;
    public nombre: string;
    public estado: string;
    public foto: string;
    public cia: string;
    public fecha: Date;
}
