export class Arccdipk {
  noCia: string;
  codiDepa: string;
  codiProv: string;
  codiDist: string;
}
