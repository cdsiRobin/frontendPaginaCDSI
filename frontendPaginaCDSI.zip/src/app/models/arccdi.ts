import { Arccdipk } from './arccdipk';
export class Arccdi {
  arccdiPK: Arccdipk;
  descDist: string;
  ubigeo: string;
}
