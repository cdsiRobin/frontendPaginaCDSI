import { IdArinmr } from './IdArinmr';
export class Arinmr{
  idMar:IdArinmr;;
    descripcion:string;
}
