import { Arpfflpk } from './arpfflpk';
export class Arpffl {
  arpfflPK: Arpfflpk;
  descripcion: string;
  cantidad: string;
  indParentesco: string;
  noLinea: number;
  tipoBs: string;
}
