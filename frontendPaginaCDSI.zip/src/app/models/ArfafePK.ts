export class ArfafePK {

    noCia: string;
    tipoDoc: string;
    noFactu: string;
    
}