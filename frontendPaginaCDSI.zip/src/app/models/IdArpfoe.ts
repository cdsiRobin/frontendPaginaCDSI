export class IdArpfoe {

  noCia: string;
  noOrden: string;

}
