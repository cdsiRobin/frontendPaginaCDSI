import {ITransaccion} from '../interfaces/ITransaccion';

export class Transaccion implements ITransaccion{
  codClasPed: string;
  codTPed: string;
  descri: string;
}
