export class IdArticulo{
  cia:string;
  noArti:string;
}
