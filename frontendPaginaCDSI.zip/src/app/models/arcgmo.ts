export class Arcgmo {
  moneda: string;
  descripcion: string;
  simbolo: string;
}
