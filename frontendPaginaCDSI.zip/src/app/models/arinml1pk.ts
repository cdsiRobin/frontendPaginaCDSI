export class Arinml1pk {
  noCia: string;
  bodega: string;
  tipoDoc: string;
  noDocu: string;
  noArti: string;
}
