export class Arfamc {
  cia: string;
  nombre: string;
  nombreAno: string;
  ruc: string;
  email: string;
  banco: string;
  cuentaSol: string;
  cuentaDol: string;
  descripcion: string;
}
