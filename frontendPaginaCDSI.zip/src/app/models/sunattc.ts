export class Sunattc {
  clase: string;
  descripcion: string;
  monto: number;
}
