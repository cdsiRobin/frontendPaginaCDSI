import { Arccdppk } from './arccdppk';
export class Arccdp {
  arccdpPK: Arccdppk;
  descDepa: string;
}
