export class ArcgtcPK {
  claseCambio: string;
  fecha: Date;
}
