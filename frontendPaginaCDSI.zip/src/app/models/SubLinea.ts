import { IdSubLinea } from './IdSubLinea';
export class SubLinea{
    idArinc:IdSubLinea;
    descripcion:string;
    estado:string;
}