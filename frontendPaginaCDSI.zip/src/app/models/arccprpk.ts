export class Arccprpk {
  noCia: string;
  codiDepa: string;
  codiProv: string;
}
