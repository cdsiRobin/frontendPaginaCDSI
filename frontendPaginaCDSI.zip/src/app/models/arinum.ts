import { Arinumpk } from './arinumpk';
export class Arinum {
  arinumPK: Arinumpk;
  nom: string;
  estado: string;
  codSunat1: string;
}
