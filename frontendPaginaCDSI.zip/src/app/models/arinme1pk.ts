export class Arinme1pk {
  noCia: string;
  bodega: string;
  tipoDoc: string;
  noDocu: string;
}
