export class Varinda1ps {
  noCia: string;
  noArti: string;
  descripcion: string;
  medida: string;
  precio: number;
  stock: number;
  tipo: string;
}
