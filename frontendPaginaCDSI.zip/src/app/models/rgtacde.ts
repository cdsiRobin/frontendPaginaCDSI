import { Astenci } from './astenci';
export class Rgtacde {
    public id: number;
    public fecha: Date;
    public astenci: Astenci;
    public longuitud: string;
    public latitud: string;
    public usuario: string;
    public cia: string;
}
