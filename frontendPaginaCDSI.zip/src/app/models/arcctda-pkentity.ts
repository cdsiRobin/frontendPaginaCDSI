export class ArcctdaPKEntity {
  noCia: string;
  noCliente: string;
  codTienda: string;
}
