export class IdArinbo1{
     cia:string;
     codigo:string;
}