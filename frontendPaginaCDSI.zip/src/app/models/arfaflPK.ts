export class arfaflPK{

    noCia: string;
    tipoDoc: string;
    noFactu: string;
    consecutivo: number;

}