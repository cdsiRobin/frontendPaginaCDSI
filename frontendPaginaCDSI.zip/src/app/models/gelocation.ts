export class Gelocation {
    public id: number;
    public cia: string;
    public usuario: string;
    public codEmp: string;
    public dni: string;
    public longitud: string;
    public latitud: string;
    public direccion: string;
    public ubigeo: string;
    public urbanizacion: string;
    public estado: string;
    public fInactivo: Date;
    public autorizacion: string;
}
