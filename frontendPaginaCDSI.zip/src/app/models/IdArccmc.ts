export class IdArccmc{
  cia:string;
  id:string;
}
