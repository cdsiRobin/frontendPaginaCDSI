export class IdCatalogo{
    cia:string;
    codigo:string;
}