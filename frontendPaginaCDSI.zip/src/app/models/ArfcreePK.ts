export class ArfcreePK {

    noCia: string;
    noOrden: string;
    noCliente: string;
    
}