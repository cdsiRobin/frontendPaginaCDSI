export class Tapfopapk {
  noCia: string;
  codFpago: string;
}
