export class Arinumpk {
  noCia: string;
  unidad: string;
}
