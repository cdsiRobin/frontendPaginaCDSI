import { Arccprpk } from './arccprpk';
export class Arccpr {
  arccprPK: Arccprpk;
  descProv: string;
}
