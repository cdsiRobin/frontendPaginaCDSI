export class IdSubLinea{
    cia:String;
	tipo:String;
	clase:String;
	codigo:String;
}