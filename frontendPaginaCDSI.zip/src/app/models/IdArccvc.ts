export class IdArccvc{
    cia:string;
    codigo:string;
}