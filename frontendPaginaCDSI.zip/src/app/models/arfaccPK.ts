import {IarfaccPK} from '../interfaces/IarfaccPK';

export class ArfaccPK implements IarfaccPK{
  centro: string;
  noCia: string;
  serie: string;
  tipoDoc: string;
}
