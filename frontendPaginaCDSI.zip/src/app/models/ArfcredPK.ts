export class ArfcredPK {
    noCia: string;
    noOrden: string;
    noCliente: string;
    noCredito: string;
}