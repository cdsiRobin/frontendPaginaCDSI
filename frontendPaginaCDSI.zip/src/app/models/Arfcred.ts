import { ArfcredPK } from "./ArfcredPK";

export class Arfcred {

    arfcredPk: ArfcredPK;
	tiempoPago: number;
	estado: string;
	descripcion: string;
	montoPagado: number;
	monto: number;
	fechaPago: string;

	constructor(){}

}