export class Arccdppk {
  noCia: string;
  codiDepa: string;
}
