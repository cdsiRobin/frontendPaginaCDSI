import { IdArccvc } from './IdArccvc';
export class Arccvc{
    idArc: IdArccvc;
    descripcion: string;
    pass: string;
}
