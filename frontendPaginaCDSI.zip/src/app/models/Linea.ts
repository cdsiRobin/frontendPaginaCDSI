import { IdLinea } from './../material/IdLinea';
export class Linea {
    idLinea:IdLinea;
    descripcion:string;
    estado:string;
}