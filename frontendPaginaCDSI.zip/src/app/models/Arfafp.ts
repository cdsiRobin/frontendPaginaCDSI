import { ArfafpPK } from './ArfafpPK';
export class Arfafp {
  arfafpPK: ArfafpPK;
  descripcion: string;
  plazo: number;
  plazo2: number;
  plazo3: number;
  plazo4: number;
  plazo5: number;
  plazo6: number;
  plazo7: number;
  plazo8: number;
  plazo9: number;
  plazo10: number;
  plazo11: number;
  plazo12: number;
  tipoFpago: string;
  estado: string;
  otrasFechas: string;
  indFechaVenc: string;
}
