export class Arinsepk {
  noCia: string;
  bodega: string;
  tipoDoc: string;
}
