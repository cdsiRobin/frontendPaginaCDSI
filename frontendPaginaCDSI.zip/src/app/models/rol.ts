export class Rol {
    public id: number;
    public authority: string;
}
