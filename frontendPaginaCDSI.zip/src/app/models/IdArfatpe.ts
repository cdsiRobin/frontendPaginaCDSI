export class IdArfatpe{
  cia:string;
  codPed:string;
}
