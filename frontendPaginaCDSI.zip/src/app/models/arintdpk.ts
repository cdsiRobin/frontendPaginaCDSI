export class Arintdpk {
  noCia: string;
  tipoM: string;
}
