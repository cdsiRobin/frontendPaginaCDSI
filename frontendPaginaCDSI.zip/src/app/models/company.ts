export class Company {
    public cia: string;
    public nombre: string;
    public nombreAno: string;
    public ruc: string;
    public razonSocial: string;
    public licencia: string;
}
