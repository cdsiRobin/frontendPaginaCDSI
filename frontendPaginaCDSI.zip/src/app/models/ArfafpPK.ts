export class ArfafpPK {
  noCia: string;
  tipoFpago: string;
  codFpago: string;
}
