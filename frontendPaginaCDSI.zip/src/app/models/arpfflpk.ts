export class Arpfflpk {
  noCia: string;
  bodega: string;
  noGuia: string;
  noArti: string;
}
