export class IdFamilia{
    cia:string;
    tipo:string;
	clase:string;
    categoria: string;
	codigo: string; 
}