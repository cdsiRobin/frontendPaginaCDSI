import { IdTapUsuPven } from './IdTapUsuPven';
export class TapUsuPven{
  idUsuario:IdTapUsuPven;

  nombre:string;
  tipusua:string;
  centro:string;
  estado:string;
  emp:string;
}
