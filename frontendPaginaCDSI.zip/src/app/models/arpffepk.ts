export class Arpffepk {
  noCia: string;
  bodega: string;
  noGuia: string;
}
