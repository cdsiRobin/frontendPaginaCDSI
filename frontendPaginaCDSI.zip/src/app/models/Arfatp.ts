import { IdArfatp } from './IdArfatp';
export class Arfatp{
    idArfa:IdArfatp;
    descripcion:string;
    moneda:string;
    codCamp:string;
    indAuto: string;
    indGeneral:string;
    indPTota:string;

}
