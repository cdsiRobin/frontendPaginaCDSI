export class BuscarItem {
  public cia: string;
  public lp: string;
  public descrip: string;

  constructor(cia: string,lp: string, descrip: string){
     this.cia = cia;
     this.lp = lp;
     this.descrip = descrip;
  }
}
