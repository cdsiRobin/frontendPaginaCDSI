import { Arinsepk } from './arinsepk';

export class Arinse {
  arinsePK: Arinsepk;
  secuencia: number;
}
