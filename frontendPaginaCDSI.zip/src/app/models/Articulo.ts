export class Articulo{
	cia :string;
	no_arti :string;
	descripcion :string ;
	medida :string ;
	marca :string ;
	precio :number ;
	stock :number ;
	compromiso :number ;
	Vigente :string ;
	fecha :string ;
	tipo_arti :string ;
	clase :string ;
	categoria :string ;
	familia :string ;
	catalogo :string ;
	linea :string ;
	subLinea :string ;
	fam :string ;
	almacen :string ;
	tipo :string ;
}