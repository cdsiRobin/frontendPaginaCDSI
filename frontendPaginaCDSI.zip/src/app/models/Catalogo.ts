import { IdCatalogo } from './idCatalogo';
export class Catalogo{
    cat:IdCatalogo;
    descripcion:string;
    estado:string;
}