export class IdTapUsuPven{
  cia:string;
  usuario:string;
}
