import { IdFamilia } from './IdFamilia';
export class Familia{
    idArfa:IdFamilia;
    descripcion:string;
    estado:string;
}