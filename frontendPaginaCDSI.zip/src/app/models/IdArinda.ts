export class IdArinda{
  cia:string;
  noArti:string;
}
