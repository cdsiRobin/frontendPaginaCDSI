export class DatosClienteDTO{
  cia: string;
  descri: string;
  documento: string;
  id: string;
  constructor(cia: string) {
    this.cia = cia;
  }
}
