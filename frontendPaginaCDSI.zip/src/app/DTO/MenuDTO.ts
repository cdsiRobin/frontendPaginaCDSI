export class MenuDTO{
  codigo:string;
  nombre:string;
}
