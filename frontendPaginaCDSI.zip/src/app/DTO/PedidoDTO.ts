import { Arpfol } from './../models/Arpfol';
import { Arpfoe } from './../models/Arpfoe';
export class PedidoDTO{
  pedido:Arpfoe;
  detallePedido:Arpfol[];
}
