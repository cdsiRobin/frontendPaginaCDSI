export class EstadosDTO{
  codigo:string;
  nombre:string;
}
