export class CorrelDTO{
  cia:string;
  orden:string;
  centro:string;
}
