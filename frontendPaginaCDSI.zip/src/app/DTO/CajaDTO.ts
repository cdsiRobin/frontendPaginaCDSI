export class CajaDTO{
  codigo:string;
  nombre:string;
  moneda:string;
}
