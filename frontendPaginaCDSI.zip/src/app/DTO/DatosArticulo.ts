export class DatosArticulo{
  precio:number;
  stock:number;
}
