export interface IArcgtcpk {
  claseCambio: string;
  fecha: Date;
}
