export interface IarfaccPK {
  noCia: string;
  centro: string;
  tipoDoc: string;
  serie: string;
}
