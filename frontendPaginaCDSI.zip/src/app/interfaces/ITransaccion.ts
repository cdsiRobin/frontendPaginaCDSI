export interface ITransaccion {
  codTPed: string;
  descri: string;
  codClasPed: string;
}
