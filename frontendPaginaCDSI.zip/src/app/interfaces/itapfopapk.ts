export interface Itapfopapk {
  noCia: string;
  codFpago: string;
}
