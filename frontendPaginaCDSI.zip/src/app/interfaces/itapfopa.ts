import { Itapfopapk } from './itapfopapk';
export interface Itapfopa {
  tapfopaPK: Itapfopapk;
  plazo: number;
  plazo2: number;
  plazo3: number;
  plazo4: number;
  plazo5: number;
  plazo6: number;
  plazo7: number;
  plazo8: number;
  plazo9: number;
  plazo10: number;
  plazo11: number;
  plazo12: number;
  tipoFpago: string;
  estado: string;
}
