export interface Estado {
  codigo: string;
  mensaje: string;
  estado: number;
  error: string;
  fechaHora: Date;
}
