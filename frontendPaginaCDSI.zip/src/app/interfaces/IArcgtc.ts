import {IArcgtcpk} from './IArcgtcpk';

export interface IArcgtc {
  arcgtcPK: IArcgtcpk;
  tipoCambio: number;
}
