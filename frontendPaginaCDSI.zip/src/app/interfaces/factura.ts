export interface Factura {
  item: number;
  codigo: string;
  medida: number;
  descripcion: string;
  tipoAfec: number;
  cantidad: number;
  pu: number;
  descu: number;
  icbCop: number;
  IGV: number;
  total: number;
}
